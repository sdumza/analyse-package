"""
     Splits a sentence into a list of the separate words
     The function takes in a dataframe and returns a dataframe with a new
      column "Split Tweets". Words are all in lowercase.

Args:
    df (DataFrame): a dataframe

Returns:
    DataFrame: a dataframe with a new column "Split Tweets"
"""
def word_spliter(df):

  ### Code Here

  pass

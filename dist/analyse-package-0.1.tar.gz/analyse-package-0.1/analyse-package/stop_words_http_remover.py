"""
     Removes the stop words and the url link from a tweet. The function follows
      the criteria below:

        1. Removes stop words based on the dictionary provided below.
        2. Removes url's from the tweets.
        3. Tokenises the sentence
        The column will be labelled as "Without Stop Words"

""""

def stop_words_http_remover(df):

  # Code Here

  pass

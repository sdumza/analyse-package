"To install: pip install git+https://github.com/kopano-m/analyse-package.git"

"To update: pip install --upgrade git+https://github.com/kopano-m/analyse-package.git"

# Analyse Package
## Installation

```bash
pip install git+https://github.com/kopano-m/analyse-package.git
pip install --upgrade git+https://github.com/kopano-m/analyse-package.git
```
## Usage

```python
from analyse_package import analyse_functions as af

af.dictionary_of_metrics(list) # returns a dictionary
```

## Contributing



## License
[MIT](https://choosealicense.com/licenses/mit/)
